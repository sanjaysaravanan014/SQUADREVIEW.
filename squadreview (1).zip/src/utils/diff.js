export function computeLineDiff(original, fixed) {
  const a = original.split('\n');
  const b = fixed.split('\n');
  const m = a.length;
  const n = b.length;

  // DP table for Longest Common Subsequence
  const dp = Array.from({ length: m + 1 }, () => new Array(n + 1).fill(0));

  for (let i = m - 1; i >= 0; i--) {
    for (let j = n - 1; j >= 0; j--) {
      if (a[i] === b[j]) {
        dp[i][j] = 1 + dp[i + 1][j + 1];
      } else {
        dp[i][j] = Math.max(dp[i + 1][j], dp[i][j + 1]);
      }
    }
  }

  const lines = [];
  let i = 0;
  let j = 0;

  while (i < m && j < n) {
    if (a[i] === b[j]) {
      lines.push({
        type: 'context',
        oldLine: i + 1,
        newLine: j + 1,
        text: a[i],
      });
      i++;
      j++;
    } else if (dp[i + 1][j] >= dp[i][j + 1]) {
      lines.push({
        type: 'removed',
        oldLine: i + 1,
        newLine: null,
        text: a[i],
      });
      i++;
    } else {
      lines.push({
        type: 'added',
        oldLine: null,
        newLine: j + 1,
        text: b[j],
      });
      j++;
    }
  }

  while (i < m) {
    lines.push({
      type: 'removed',
      oldLine: i + 1,
      newLine: null,
      text: a[i],
    });
    i++;
  }

  while (j < n) {
    lines.push({
      type: 'added',
      oldLine: null,
      newLine: j + 1,
      text: b[j],
    });
    j++;
  }

  return lines;
}
