import { CheckCircle2, Circle, Loader2, AlertTriangle } from 'lucide-react';

export function AgentPipelineBar({ stages }) {
  return (
    <div className="border border-slate-200 bg-white rounded-xl overflow-hidden shadow-xs">
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 divide-y sm:divide-y-0 sm:divide-x divide-slate-200">
        {stages.map((stage, index) => {
          const isReflection = stage.id === 'reflection';
          const stepBarClass =
            stage.state === 'complete'
              ? 'bg-emerald-500'
              : stage.state === 'running'
              ? 'bg-blue-600'
              : stage.state === 'error'
              ? 'bg-rose-500'
              : 'bg-transparent';

          return (
            <div
              key={stage.id}
              className={`relative px-4 py-3.5 transition-colors ${
                stage.state === 'running'
                  ? 'bg-blue-50/50'
                  : stage.state === 'complete'
                  ? 'bg-white'
                  : 'bg-slate-50/30'
              } ${isReflection ? 'lg:col-span-5 border-t border-slate-200' : ''}`}
            >
              <div
                className={`absolute top-0 left-0 right-0 h-0.5 transition-colors ${stepBarClass}`}
              />
              <div className="flex items-center justify-between gap-2 mb-1">
                <div className="flex items-center gap-2 min-w-0">
                  {stage.state === 'running' && (
                    <Loader2 className="w-4 h-4 text-blue-600 animate-spin shrink-0" />
                  )}
                  {stage.state === 'complete' && (
                    <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                  )}
                  {stage.state === 'error' && (
                    <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0" />
                  )}
                  {stage.state === 'idle' && (
                    <Circle className="w-4 h-4 text-slate-300 shrink-0" />
                  )}
                  <span className="text-xs font-semibold text-slate-900 truncate">
                    {index + 1}. {stage.label}
                  </span>
                </div>
                {typeof stage.durationMs === 'number' && (
                  <span className="text-[11px] font-mono tabular-nums text-slate-500 shrink-0">
                    {(stage.durationMs / 1000).toFixed(2)}s
                  </span>
                )}
              </div>
              <p className="text-xs text-slate-600 line-clamp-2 leading-relaxed">
                {stage.detail}
              </p>
            </div>
          );
        })}
      </div>
    </div>
  );
}
