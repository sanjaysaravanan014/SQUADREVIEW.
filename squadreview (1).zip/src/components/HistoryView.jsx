import { ArrowUpRight, CheckCircle2, Trash2, XCircle } from 'lucide-react';

export function HistoryView({ history, onSelectReview, onClearHistory }) {
  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="text-2xl font-semibold text-slate-900">
            Review History
          </h1>
          <p className="mt-1 text-sm text-slate-600">
            Saved multi-agent review reports, diffs, and sandbox verification runs
            from this browser session.
          </p>
        </div>

        {history.length > 0 && (
          <button
            type="button"
            onClick={onClearHistory}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-medium text-slate-700 bg-white border border-slate-200 rounded-md hover:bg-slate-50 transition-colors whitespace-nowrap shrink-0"
          >
            <Trash2 className="w-3.5 h-3.5 text-slate-500" />
            <span>Clear History</span>
          </button>
        )}
      </div>

      {history.length === 0 ? (
        <div className="border border-slate-200 rounded-lg bg-white px-6 py-14 text-center">
          <p className="text-sm text-slate-600">
            No completed reviews yet. Submit a snippet in the Workbench to see
            saved reports here.
          </p>
        </div>
      ) : (
        <div className="border border-slate-200 rounded-lg bg-white overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-slate-200 bg-slate-50 text-xs font-medium text-slate-500">
                <th className="py-3 px-4">Snippet</th>
                <th className="py-3 px-4">Language</th>
                <th className="py-3 px-4">Intent</th>
                <th className="py-3 px-4 text-right">Bugs</th>
                <th className="py-3 px-4 text-right">Style</th>
                <th className="py-3 px-4">Sandbox</th>
                <th className="py-3 px-4 text-right">Duration</th>
                <th className="py-3 px-4 text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200 text-sm">
              {history.map((item) => (
                <tr key={item.id} className="hover:bg-slate-50/70">
                  <td className="py-3 px-4 font-medium text-slate-900">
                    <div>{item.title}</div>
                    <div className="text-xs text-slate-500 font-normal">
                      {new Date(item.createdAt).toLocaleString()}
                    </div>
                  </td>
                  <td className="py-3 px-4 text-xs text-slate-600">
                    {item.language === 'python' ? 'Python' : 'JavaScript'}
                  </td>
                  <td className="py-3 px-4 text-xs text-slate-600 capitalize">
                    {item.intent.primary.replace('_', ' ')}
                  </td>
                  <td className="py-3 px-4 text-right font-mono text-xs tabular-nums text-slate-800">
                    {item.bugs.length}
                  </td>
                  <td className="py-3 px-4 text-right font-mono text-xs tabular-nums text-slate-800">
                    {item.styleIssues.length}
                  </td>
                  <td className="py-3 px-4 text-xs">
                    {item.sandboxFixed.passed ? (
                      <span className="inline-flex items-center gap-1 text-emerald-700 font-medium">
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        <span>Passed</span>
                      </span>
                    ) : (
                      <span className="inline-flex items-center gap-1 text-rose-700 font-medium">
                        <XCircle className="w-3.5 h-3.5" />
                        <span>Failed</span>
                      </span>
                    )}
                  </td>
                  <td className="py-3 px-4 text-right font-mono text-xs tabular-nums text-slate-600">
                    {(item.totalDurationMs / 1000).toFixed(2)}s
                  </td>
                  <td className="py-3 px-4 text-right">
                    <button
                      type="button"
                      onClick={() => onSelectReview(item)}
                      className="inline-flex items-center gap-1 px-3 py-1.5 text-xs font-medium text-blue-700 hover:text-blue-800 hover:bg-blue-50 rounded transition-colors whitespace-nowrap"
                    >
                      <span>View Report</span>
                      <ArrowUpRight className="w-3.5 h-3.5" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
