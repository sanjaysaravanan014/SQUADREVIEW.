import { Code2, Eraser } from 'lucide-react';
import { useRef } from 'react';

export function CodeEditor({
  code,
  language,
  onChangeCode,
  onChangeLanguage,
}) {
  const gutterRef = useRef(null);
  const textareaRef = useRef(null);

  const lines = code ? code.split('\n') : [''];
  const lineCount = Math.max(12, lines.length);

  const handleScroll = () => {
    if (gutterRef.current && textareaRef.current) {
      gutterRef.current.scrollTop = textareaRef.current.scrollTop;
    }
  };

  const handleKeyDown = (e) => {
    if (e.key === 'Tab') {
      e.preventDefault();
      const target = e.currentTarget;
      const start = target.selectionStart;
      const end = target.selectionEnd;
      const indent = language === 'python' ? '    ' : '  ';
      const next = code.slice(0, start) + indent + code.slice(end);
      onChangeCode(next);
      requestAnimationFrame(() => {
        if (textareaRef.current) {
          textareaRef.current.selectionStart = start + indent.length;
          textareaRef.current.selectionEnd = start + indent.length;
        }
      });
    }
  };

  return (
    <div className="border border-slate-200 rounded-xl bg-white overflow-hidden shadow-xs flex flex-col">
      {/* Editor Header */}
      <div className="px-4 py-2.5 bg-slate-900 border-b border-slate-800 flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2 text-xs font-medium text-slate-200">
            <Code2 className="w-4 h-4 text-blue-400" />
            <span className="font-mono">
              {language === 'python' ? 'solution.py' : 'solution.mjs'}
            </span>
          </div>
          <span className="text-xs text-slate-600" aria-hidden="true">
            ·
          </span>
          <span className="text-xs font-mono tabular-nums text-slate-400">
            {lines.length} {lines.length === 1 ? 'line' : 'lines'}
          </span>
        </div>

        <div className="flex items-center gap-2">
          {code.length > 0 && (
            <button
              type="button"
              onClick={() => onChangeCode('')}
              className="inline-flex items-center gap-1 px-2.5 py-1 text-xs text-slate-300 hover:text-white hover:bg-slate-800 rounded transition-colors whitespace-nowrap shrink-0"
            >
              <Eraser className="w-3.5 h-3.5" />
              <span>Clear</span>
            </button>
          )}
          <div
            role="group"
            aria-label="Programming language"
            className="flex items-center gap-0.5 p-0.5 bg-slate-800 rounded-md border border-slate-700"
          >
            {[
              ['python', 'Python'],
              ['javascript', 'JavaScript'],
            ].map(([id, label]) => (
              <button
                key={id}
                type="button"
                onClick={() => onChangeLanguage(id)}
                className={`px-2.5 py-1 text-xs font-medium rounded transition-colors whitespace-nowrap shrink-0 ${
                  language === id
                    ? 'bg-blue-600 text-white'
                    : 'text-slate-300 hover:text-white'
                }`}
              >
                {label}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Synchronized Line-Numbered Editor Body */}
      <div className="relative flex flex-1 min-h-[340px] max-h-[480px] bg-slate-950 overflow-hidden">
        <div
          ref={gutterRef}
          aria-hidden="true"
          className="w-12 py-4 pr-3 pl-2 bg-slate-950 border-r border-slate-800/80 text-right font-mono text-[13px] leading-[1.6] text-slate-600 select-none overflow-hidden tabular-nums shrink-0"
        >
          {Array.from({ length: lineCount }, (_, idx) => (
            <div key={idx}>{idx + 1}</div>
          ))}
        </div>

        <textarea
          ref={textareaRef}
          value={code}
          onChange={(e) => onChangeCode(e.target.value)}
          onScroll={handleScroll}
          onKeyDown={handleKeyDown}
          spellCheck={false}
          placeholder={
            language === 'python'
              ? 'def binary_search(arr, target):\n    left, right = 0, len(arr) - 1\n    ...\n\n# Paste your Python function or module here'
              : 'function calculateTotal(items) {\n  ...\n}\n\n// Paste your JavaScript function or module here'
          }
          aria-label="Source code editor"
          className="code-editor flex-1 w-full py-4 px-4 bg-slate-950 text-slate-100 placeholder:text-slate-600 font-mono text-[13px] leading-[1.6] focus:outline-none resize-none overflow-auto"
        />
      </div>
    </div>
  );
}
