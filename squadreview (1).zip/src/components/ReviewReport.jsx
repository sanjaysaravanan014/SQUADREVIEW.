import {
  AlertCircle,
  AlertTriangle,
  BookOpen,
  CheckCircle2,
  ChevronDown,
  ChevronUp,
  Info,
  Play,
  RefreshCw,
  Terminal,
  XCircle,
} from 'lucide-react';
import { useEffect, useState } from 'react';
import { DiffViewer } from './DiffViewer.jsx';

function formatIntentLabel(intent) {
  return intent
    .split('_')
    .map((w) => w.charAt(0).toUpperCase() + w.slice(1))
    .join(' ');
}

export function ReviewReport({ result, onApplyFix }) {
  const [activeTab, setActiveTab] = useState('summary');
  const [expandedDocId, setExpandedDocId] = useState(
    result.retrievedDocs[0]?.id ?? null
  );
  const [editableTestCode, setEditableTestCode] = useState(result.testCode);
  const [liveOriginalSandbox, setLiveOriginalSandbox] = useState(
    result.sandboxOriginal
  );
  const [liveFixedSandbox, setLiveFixedSandbox] = useState(result.sandboxFixed);
  const [isReRunning, setIsReRunning] = useState(false);
  const [sandboxError, setSandboxError] = useState(null);

  useEffect(() => {
    setEditableTestCode(result.testCode);
    setLiveOriginalSandbox(result.sandboxOriginal);
    setLiveFixedSandbox(result.sandboxFixed);
    setExpandedDocId(result.retrievedDocs[0]?.id ?? null);
    setSandboxError(null);
  }, [result]);

  const handleRerunSandbox = async () => {
    setIsReRunning(true);
    setSandboxError(null);
    try {
      const [origRes, fixRes] = await Promise.all([
        fetch('/api/sandbox/run', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            code: result.originalCode,
            testCode: editableTestCode,
            language: result.language,
          }),
        }),
        fetch('/api/sandbox/run', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            code: result.fixedCode,
            testCode: editableTestCode,
            language: result.language,
          }),
        }),
      ]);

      const origJson = await origRes.json();
      const fixJson = await fixRes.json();
      if (!origRes.ok || !fixRes.ok) {
        throw new Error(origJson.error || fixJson.error || 'Sandbox run failed.');
      }
      setLiveOriginalSandbox(origJson.result);
      setLiveFixedSandbox(fixJson.result);
    } catch (err) {
      setSandboxError(
        err instanceof Error ? err.message : 'Unable to execute tests in sandbox.'
      );
    } finally {
      setIsReRunning(false);
    }
  };

  const criticalOrHighCount = result.bugs.filter(
    (b) => b.severity === 'critical' || b.severity === 'high'
  ).length;

  return (
    <div className="space-y-5">
      {/* Header summary strip */}
      <div className="border border-slate-200 rounded-xl bg-white overflow-hidden shadow-xs">
        <div className="px-5 py-4 border-b border-slate-200 flex flex-wrap items-center justify-between gap-4">
          <div>
            <h2 className="text-lg font-semibold text-slate-900">
              {result.title}
            </h2>
            <p className="text-xs text-slate-500 mt-0.5 tabular-nums">
              {result.language === 'python' ? 'Python 3.10' : 'Node.js 22'} ·{' '}
              Reviewed in {(result.totalDurationMs / 1000).toFixed(2)}s ·{' '}
              {result.retrievedDocs.length} RAG guidelines applied
            </p>
          </div>
          <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-lg">
            {[
              ['summary', 'Overview & RAG'],
              ['findings', `Bugs & Style (${result.bugs.length + result.styleIssues.length})`],
              ['diff', 'Code Diff'],
              ['sandbox', 'Test Sandbox'],
            ].map(([id, label]) => (
              <button
                key={id}
                type="button"
                onClick={() => setActiveTab(id)}
                className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 ${
                  activeTab === id
                    ? 'bg-white text-slate-900 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                {label}
              </button>
            ))}
          </div>
        </div>

        {/* 4-column metric bar */}
        <div className="grid grid-cols-2 lg:grid-cols-4 divide-y lg:divide-y-0 lg:divide-x divide-slate-200">
          <div className="px-5 py-3.5">
            <div className="text-xs text-slate-500">Detected Intent</div>
            <div className="mt-1 text-sm font-semibold text-slate-900">
              {formatIntentLabel(result.intent.primary)}
            </div>
            <div className="mt-0.5 text-xs text-slate-500 tabular-nums">
              {Math.round(result.intent.confidence * 100)}% routing confidence
            </div>
          </div>

          <div className="px-5 py-3.5">
            <div className="text-xs text-slate-500">Bug-Finder Agent</div>
            <div className="mt-1 text-sm font-semibold text-slate-900 tabular-nums">
              {result.bugs.length} {result.bugs.length === 1 ? 'Issue' : 'Issues'}
            </div>
            <div className="mt-0.5 text-xs text-slate-500 tabular-nums">
              {criticalOrHighCount} critical or high severity
            </div>
          </div>

          <div className="px-5 py-3.5">
            <div className="text-xs text-slate-500">Style / Lint Agent</div>
            <div className="mt-1 text-sm font-semibold text-slate-900 tabular-nums">
              {result.styleIssues.length}{' '}
              {result.styleIssues.length === 1 ? 'Note' : 'Notes'}
            </div>
            <div className="mt-0.5 text-xs text-slate-500">
              {result.syntaxCheckOriginal.valid
                ? 'Original syntax valid'
                : 'Syntax error in original'}
            </div>
          </div>

          <div className="px-5 py-3.5">
            <div className="text-xs text-slate-500">Sandbox Verification</div>
            <div className="mt-1 flex items-center gap-1.5 text-sm font-semibold">
              {liveFixedSandbox.passed ? (
                <>
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                  <span className="text-emerald-700">Fixed Code Passed</span>
                </>
              ) : (
                <>
                  <XCircle className="w-4 h-4 text-rose-600 shrink-0" />
                  <span className="text-rose-700">Tests Failing</span>
                </>
              )}
            </div>
            <div className="mt-0.5 text-xs text-slate-500 tabular-nums">
              Original: {liveOriginalSandbox.passed ? 'Passed' : 'Failed'} · Fixed:{' '}
              {liveFixedSandbox.testsRun} run ({liveFixedSandbox.durationMs}ms)
            </div>
          </div>
        </div>
      </div>

      {/* Tab 1: Overview & Agentic RAG */}
      {activeTab === 'summary' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 items-start">
          <div className="lg:col-span-7 space-y-5">
            <div className="border border-slate-200 rounded-lg bg-white divide-y divide-slate-200">
              <div className="px-5 py-4">
                <h3 className="text-sm font-semibold text-slate-900">
                  Code Walkthrough & Explanation
                </h3>
                <div className="mt-2.5 text-sm text-slate-700 leading-relaxed whitespace-pre-line">
                  {result.explanation}
                </div>
              </div>

              <div className="px-5 py-4">
                <h3 className="text-sm font-semibold text-slate-900">
                  Changes Applied by Fixer Agent
                </h3>
                <ul className="mt-2.5 space-y-2">
                  {result.fixSummary.map((item, i) => (
                    <li
                      key={i}
                      className="flex items-start gap-2.5 text-sm text-slate-700"
                    >
                      <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                      <span>{item}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {result.reflectionApplied && (
                <div className="px-5 py-4 bg-amber-50/50">
                  <div className="flex items-center gap-2 text-sm font-semibold text-amber-900">
                    <RefreshCw className="w-4 h-4 text-amber-700" />
                    <span>Reflection Self-Correction Applied</span>
                  </div>
                  <p className="mt-1.5 text-sm text-amber-900/90 leading-relaxed">
                    {result.reflectionNote}
                  </p>
                </div>
              )}
            </div>
          </div>

          <div className="lg:col-span-5 space-y-5">
            {/* Intent & Crew Plan */}
            <div className="border border-slate-200 rounded-lg bg-white divide-y divide-slate-200">
              <div className="px-5 py-4">
                <h3 className="text-sm font-semibold text-slate-900">
                  Intent Routing & Retrieval Queries
                </h3>
                <p className="mt-1.5 text-xs text-slate-600 leading-relaxed">
                  {result.intent.rationale}
                </p>
                <div className="mt-3 space-y-1">
                  <div className="text-xs font-medium text-slate-500">
                    RAG Search Queries
                  </div>
                  {result.intent.retrievalQueries.map((q, idx) => (
                    <div
                      key={idx}
                      className="text-xs font-mono text-slate-800 bg-slate-50 border border-slate-200 rounded px-2.5 py-1.5"
                    >
                      {q}
                    </div>
                  ))}
                </div>
              </div>

              <div className="px-5 py-4">
                <div className="flex items-center justify-between gap-2 mb-2.5">
                  <h3 className="text-sm font-semibold text-slate-900 flex items-center gap-2">
                    <BookOpen className="w-4 h-4 text-blue-600" />
                    <span>Retrieved Knowledge Guidance</span>
                  </h3>
                  <span className="text-xs text-slate-500 tabular-nums">
                    Top {result.retrievedDocs.length}
                  </span>
                </div>

                <div className="divide-y divide-slate-200 border border-slate-200 rounded-md">
                  {result.retrievedDocs.map((doc) => {
                    const isOpen = expandedDocId === doc.id;
                    return (
                      <div key={doc.id} className="bg-white">
                        <button
                          type="button"
                          onClick={() =>
                            setExpandedDocId(isOpen ? null : doc.id)
                          }
                          className="w-full text-left px-3.5 py-2.5 hover:bg-slate-50 transition-colors flex items-start justify-between gap-3"
                        >
                          <div className="min-w-0">
                            <div className="text-xs font-semibold text-slate-900">
                              {doc.title}
                            </div>
                            <div className="text-[11px] text-slate-500 mt-0.5 tabular-nums">
                              {doc.category.replace('_', ' ')} · {doc.language} ·{' '}
                              {Math.round(doc.score * 100)}% match ({doc.matchedBy})
                            </div>
                          </div>
                          {isOpen ? (
                            <ChevronUp className="w-4 h-4 text-slate-400 shrink-0 mt-0.5" />
                          ) : (
                            <ChevronDown className="w-4 h-4 text-slate-400 shrink-0 mt-0.5" />
                          )}
                        </button>
                        {isOpen && (
                          <div className="px-3.5 pb-3 pt-1 text-xs text-slate-700 leading-relaxed bg-slate-50/70 border-t border-slate-100">
                            {doc.content}
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Tab 2: Bugs & Style */}
      {activeTab === 'findings' && (
        <div className="space-y-5">
          {/* Bug-Finder Section */}
          <div className="border border-slate-200 rounded-lg bg-white overflow-hidden">
            <div className="px-5 py-3.5 bg-slate-50 border-b border-slate-200 flex items-center justify-between">
              <h3 className="text-sm font-semibold text-slate-900">
                Bug-Finder Agent Findings
              </h3>
              <span className="text-xs text-slate-500 tabular-nums">
                {result.bugs.length} detected
              </span>
            </div>

            {result.bugs.length === 0 ? (
              <div className="px-5 py-8 text-center text-sm text-slate-600">
                No logical or runtime bugs were detected in this snippet.
              </div>
            ) : (
              <div className="divide-y divide-slate-200">
                {result.bugs.map((bug) => {
                  const severityColor =
                    bug.severity === 'critical' || bug.severity === 'high'
                      ? 'text-rose-700'
                      : bug.severity === 'medium'
                      ? 'text-amber-700'
                      : 'text-slate-600';
                  return (
                    <div key={bug.id} className="px-5 py-4">
                      <div className="flex flex-wrap items-center justify-between gap-2">
                        <div className="flex items-center gap-2">
                          <AlertCircle className={`w-4 h-4 shrink-0 ${severityColor}`} />
                          <span className="text-sm font-semibold text-slate-900">
                            {bug.title}
                          </span>
                        </div>
                        <div className="text-xs font-mono tabular-nums text-slate-500">
                          <span className={`font-semibold uppercase ${severityColor}`}>
                            {bug.severity}
                          </span>{' '}
                          · Line {bug.line} · {bug.category}
                        </div>
                      </div>
                      <p className="mt-2 text-sm text-slate-700 leading-relaxed">
                        {bug.explanation}
                      </p>
                      <p className="mt-1.5 text-xs text-slate-500">
                        <span className="font-medium text-slate-700">Impact:</span>{' '}
                        {bug.impact}
                      </p>
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          {/* Style / Lint Section */}
          <div className="border border-slate-200 rounded-lg bg-white overflow-hidden">
            <div className="px-5 py-3.5 bg-slate-50 border-b border-slate-200 flex items-center justify-between">
              <h3 className="text-sm font-semibold text-slate-900">
                Style & Lint Agent Notes
              </h3>
              <span className="text-xs text-slate-500 tabular-nums">
                {result.styleIssues.length} notes
              </span>
            </div>

            {result.styleIssues.length === 0 ? (
              <div className="px-5 py-8 text-center text-sm text-slate-600">
                Code adheres cleanly to language conventions.
              </div>
            ) : (
              <div className="divide-y divide-slate-200">
                {result.styleIssues.map((issue) => (
                  <div key={issue.id} className="px-5 py-4">
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <div className="flex items-center gap-2">
                        {issue.severity === 'warning' ? (
                          <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0" />
                        ) : (
                          <Info className="w-4 h-4 text-blue-600 shrink-0" />
                        )}
                        <span className="text-sm font-semibold text-slate-900">
                          {issue.rule}
                        </span>
                      </div>
                      <div className="text-xs font-mono tabular-nums text-slate-500">
                        {issue.severity} · Line {issue.line}
                        {issue.guidelineRef ? ` · ${issue.guidelineRef}` : ''}
                      </div>
                    </div>
                    <p className="mt-1.5 text-sm text-slate-700 leading-relaxed">
                      {issue.message}
                    </p>
                    <p className="mt-1.5 text-xs text-slate-600 bg-slate-50 border border-slate-200 rounded px-3 py-2">
                      <span className="font-medium text-slate-900">Suggestion:</span>{' '}
                      {issue.suggestion}
                    </p>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {/* Tab 3: Diff */}
      {activeTab === 'diff' && (
        <DiffViewer
          originalCode={result.originalCode}
          fixedCode={result.fixedCode}
          onApplyFix={onApplyFix}
        />
      )}

      {/* Tab 4: Isolated Test Sandbox */}
      {activeTab === 'sandbox' && (
        <div className="space-y-5">
          {/* Side-by-side execution comparison */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            {[
              { label: 'Original Submission', run: liveOriginalSandbox },
              { label: 'Fixed Code Verification', run: liveFixedSandbox },
            ].map(({ label, run }) => (
              <div
                key={label}
                className="border border-slate-200 rounded-lg bg-white overflow-hidden"
              >
                <div className="px-4 py-3 bg-slate-50 border-b border-slate-200 flex items-center justify-between gap-2">
                  <div className="flex items-center gap-2">
                    {run.passed ? (
                      <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                    ) : (
                      <XCircle className="w-4 h-4 text-rose-600 shrink-0" />
                    )}
                    <span className="text-sm font-semibold text-slate-900">
                      {label}
                    </span>
                  </div>
                  <span className="text-xs font-mono tabular-nums text-slate-500">
                    {run.passed ? 'PASS' : 'FAIL'} · exit {run.exitCode ?? 'timeout'} ·{' '}
                    {run.durationMs}ms
                  </span>
                </div>
                <pre className="p-4 bg-slate-950 text-slate-200 font-mono text-xs overflow-x-auto max-h-60 overflow-y-auto whitespace-pre-wrap leading-relaxed">
                  {[run.stdout, run.stderr].filter(Boolean).join('\n\n') ||
                    '(No output)'}
                </pre>
              </div>
            ))}
          </div>

          {/* Editable Test Harness */}
          <div className="border border-slate-200 rounded-lg bg-white overflow-hidden">
            <div className="px-4 py-3 bg-slate-50 border-b border-slate-200 flex flex-wrap items-center justify-between gap-3">
              <div className="flex items-center gap-2">
                <Terminal className="w-4 h-4 text-slate-600" />
                <span className="text-sm font-semibold text-slate-900">
                  Generated Unit Test Suite
                </span>
                <span className="text-xs text-slate-500 tabular-nums">
                  · {result.testCasesSummary.length} cases
                </span>
              </div>
              <button
                type="button"
                onClick={handleRerunSandbox}
                disabled={isReRunning}
                className="inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-medium text-white bg-blue-600 rounded-md hover:bg-blue-700 disabled:opacity-50 transition-colors whitespace-nowrap shrink-0"
              >
                <Play className="w-3.5 h-3.5" />
                <span>{isReRunning ? 'Executing...' : 'Re-Run in Sandbox'}</span>
              </button>
            </div>

            {sandboxError && (
              <div className="px-4 py-2.5 bg-rose-50 border-b border-rose-200 text-xs text-rose-700">
                {sandboxError}
              </div>
            )}

            <textarea
              value={editableTestCode}
              onChange={(e) => setEditableTestCode(e.target.value)}
              spellCheck={false}
              aria-label="Generated unit test code"
              className="w-full h-72 p-4 bg-slate-950 text-slate-100 font-mono text-xs leading-relaxed focus:outline-none resize-y"
            />

            {result.testCasesSummary.length > 0 && (
              <div className="border-t border-slate-200 divide-y divide-slate-200">
                {result.testCasesSummary.map((tc, i) => (
                  <div
                    key={i}
                    className="px-4 py-2.5 flex flex-wrap items-baseline justify-between gap-2 text-xs"
                  >
                    <span className="font-mono font-medium text-slate-900">
                      {tc.name}
                    </span>
                    <span className="text-slate-600">{tc.purpose}</span>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
