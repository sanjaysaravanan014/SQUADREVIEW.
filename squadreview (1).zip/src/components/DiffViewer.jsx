import { Check, Copy, ArrowLeftRight } from 'lucide-react';
import { useMemo, useState } from 'react';
import { computeLineDiff } from '../utils/diff.js';

export function DiffViewer({ originalCode, fixedCode, onApplyFix }) {
  const [mode, setMode] = useState('diff');
  const [copied, setCopied] = useState(false);

  const diffLines = useMemo(
    () => computeLineDiff(originalCode, fixedCode),
    [originalCode, fixedCode]
  );

  const stats = useMemo(() => {
    let added = 0;
    let removed = 0;
    for (const line of diffLines) {
      if (line.type === 'added') added++;
      if (line.type === 'removed') removed++;
    }
    return { added, removed };
  }, [diffLines]);

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(fixedCode);
      setCopied(true);
      setTimeout(() => setCopied(false), 1800);
    } catch {
      // Clipboard fallback ignored cleanly
    }
  };

  return (
    <div className="border border-slate-200 rounded-lg bg-white overflow-hidden">
      <div className="flex flex-wrap items-center justify-between gap-3 px-4 py-2.5 bg-slate-50 border-b border-slate-200">
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-1 p-0.5 bg-slate-200/70 rounded-md">
            <button
              type="button"
              onClick={() => setMode('diff')}
              className={`px-2.5 py-1 text-xs font-medium rounded transition-colors whitespace-nowrap shrink-0 ${
                mode === 'diff'
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Unified Diff
            </button>
            <button
              type="button"
              onClick={() => setMode('fixed')}
              className={`px-2.5 py-1 text-xs font-medium rounded transition-colors whitespace-nowrap shrink-0 ${
                mode === 'fixed'
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Fixed Source
            </button>
          </div>
          <div className="text-xs font-mono tabular-nums text-slate-600 flex items-center gap-2">
            <span className="text-emerald-700">+{stats.added}</span>
            <span aria-hidden="true">·</span>
            <span className="text-rose-700">-{stats.removed}</span>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={handleCopy}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-700 bg-white border border-slate-200 rounded-md hover:bg-slate-50 transition-colors whitespace-nowrap shrink-0"
          >
            {copied ? (
              <Check className="w-3.5 h-3.5 text-emerald-600" />
            ) : (
              <Copy className="w-3.5 h-3.5 text-slate-500" />
            )}
            <span>{copied ? 'Copied' : 'Copy Fix'}</span>
          </button>
          <button
            type="button"
            onClick={() => onApplyFix(fixedCode)}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-white bg-blue-600 rounded-md hover:bg-blue-700 transition-colors whitespace-nowrap shrink-0"
          >
            <ArrowLeftRight className="w-3.5 h-3.5" />
            <span>Load into Editor</span>
          </button>
        </div>
      </div>

      {mode === 'diff' ? (
        <div className="bg-slate-950 text-slate-100 font-mono text-xs overflow-x-auto max-h-[460px] overflow-y-auto">
          <table className="w-full border-collapse">
            <tbody>
              {diffLines.map((line, idx) => {
                const rowClass =
                  line.type === 'added'
                    ? 'bg-emerald-950/55 text-emerald-200'
                    : line.type === 'removed'
                    ? 'bg-rose-950/55 text-rose-200'
                    : 'text-slate-300';
                const marker =
                  line.type === 'added'
                    ? '+'
                    : line.type === 'removed'
                    ? '-'
                    : ' ';
                const markerClass =
                  line.type === 'added'
                    ? 'text-emerald-400'
                    : line.type === 'removed'
                    ? 'text-rose-400'
                    : 'text-slate-600';

                return (
                  <tr key={idx} className={rowClass}>
                    <td className="w-10 select-none text-right pr-2 pl-3 py-0.5 text-slate-500 tabular-nums border-r border-slate-800/80">
                      {line.oldLine ?? ''}
                    </td>
                    <td className="w-10 select-none text-right pr-2 pl-2 py-0.5 text-slate-500 tabular-nums border-r border-slate-800/80">
                      {line.newLine ?? ''}
                    </td>
                    <td className={`w-6 select-none text-center py-0.5 ${markerClass}`}>
                      {marker}
                    </td>
                    <td className="pr-4 py-0.5 whitespace-pre">{line.text}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      ) : (
        <div className="bg-slate-950 text-slate-100 font-mono text-xs overflow-x-auto max-h-[460px] overflow-y-auto">
          <table className="w-full border-collapse">
            <tbody>
              {fixedCode.split('\n').map((line, idx) => (
                <tr key={idx} className="hover:bg-slate-900/60">
                  <td className="w-12 select-none text-right pr-3 pl-3 py-0.5 text-slate-500 tabular-nums border-r border-slate-800/80">
                    {idx + 1}
                  </td>
                  <td className="pl-4 pr-4 py-0.5 whitespace-pre text-slate-200">
                    {line}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
