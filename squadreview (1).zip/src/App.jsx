import {
  AlertCircle,
  Bug,
  CheckSquare,
  Play,
  RotateCcw,
  Sparkles,
  Terminal,
} from 'lucide-react';
import { useEffect, useRef, useState } from 'react';
import { AgentPipelineBar } from './components/AgentPipelineBar.jsx';
import { CodeEditor } from './components/CodeEditor.jsx';
import { HistoryView } from './components/HistoryView.jsx';
import { ReviewReport } from './components/ReviewReport.jsx';

const HISTORY_STORAGE_KEY = 'squadreview_history_v1';

const INITIAL_STAGES = [
  {
    id: 'intent_rag',
    label: 'Intent & RAG',
    state: 'idle',
    detail: 'Classifies request intent and retrieves matching guidelines.',
  },
  {
    id: 'bug_finder',
    label: 'Bug-Finder',
    state: 'idle',
    detail: 'Detects logic errors, boundary failures, and runtime risks.',
  },
  {
    id: 'style_lint',
    label: 'Style / Lint',
    state: 'idle',
    detail: 'Checks naming, readability, and language conventions.',
  },
  {
    id: 'fixer',
    label: 'Fixer',
    state: 'idle',
    detail: 'Rewrites code to resolve detected issues cleanly.',
  },
  {
    id: 'test_sandbox',
    label: 'Test Sandbox',
    state: 'idle',
    detail: 'Generates unit tests and runs them in an isolated process.',
  },
];

const CREW_ROSTER = [
  {
    icon: Bug,
    role: 'Bug-Finder',
    scope: 'Logic errors, off-by-one bounds & runtime risks',
  },
  {
    icon: CheckSquare,
    role: 'Style / Lint',
    scope: 'Naming, types, readability & RAG conventions',
  },
  {
    icon: Sparkles,
    role: 'Fixer',
    scope: 'Clean rewrite preserving public signatures',
  },
  {
    icon: Terminal,
    role: 'Test Sandbox',
    scope: 'Automated unit tests in isolated python3 / node',
  },
];

function loadSavedHistory() {
  try {
    const raw = localStorage.getItem(HISTORY_STORAGE_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

export default function App() {
  const [view, setView] = useState('workbench');
  const [language, setLanguage] = useState('python');
  const [code, setCode] = useState('');
  const [studentGoal, setStudentGoal] = useState('');
  const [stages, setStages] = useState(INITIAL_STAGES);
  const [isRunning, setIsRunning] = useState(false);
  const [errorMsg, setErrorMsg] = useState(null);
  const [currentReport, setCurrentReport] = useState(null);
  const [history, setHistory] = useState(loadSavedHistory);

  const abortRef = useRef(null);
  const reportAnchorRef = useRef(null);

  useEffect(() => {
    try {
      localStorage.setItem(
        HISTORY_STORAGE_KEY,
        JSON.stringify(history.slice(0, 20))
      );
    } catch {
      // Ignore storage quota errors
    }
  }, [history]);

  const handleNewReview = () => {
    if (abortRef.current) {
      abortRef.current.abort();
      abortRef.current = null;
    }
    setIsRunning(false);
    setCode('');
    setStudentGoal('');
    setCurrentReport(null);
    setErrorMsg(null);
    setStages(INITIAL_STAGES);
    setView('workbench');
  };

  const handleApplyFixToEditor = (fixedCode) => {
    setCode(fixedCode);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const updateStage = (stageId, patch) => {
    setStages((prev) => {
      const exists = prev.some((s) => s.id === stageId);
      if (!exists && stageId === 'reflection') {
        return [
          ...prev,
          {
            id: 'reflection',
            label: 'Agentic Reflection',
            state: 'running',
            detail: 'Refining fix after sandbox failure...',
            ...patch,
          },
        ];
      }
      return prev.map((s) => (s.id === stageId ? { ...s, ...patch } : s));
    });
  };

  const handleRunReview = async (e) => {
    if (e) e.preventDefault();
    if (!code.trim() || isRunning) return;

    if (abortRef.current) {
      abortRef.current.abort();
    }
    const controller = new AbortController();
    abortRef.current = controller;

    setIsRunning(true);
    setErrorMsg(null);
    setCurrentReport(null);
    setStages(INITIAL_STAGES);

    try {
      const response = await fetch('/api/review/stream', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          code,
          language,
          studentGoal,
        }),
        signal: controller.signal,
      });

      if (!response.ok || !response.body) {
        const errJson = await response.json().catch(() => ({}));
        throw new Error(errJson.error || 'Failed to start squad review.');
      }

      const reader = response.body.getReader();
      const decoder = new TextDecoder();
      let buffer = '';

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        buffer += decoder.decode(value, { stream: true });

        const lines = buffer.split('\n\n');
        buffer = lines.pop() ?? '';

        for (const block of lines) {
          const dataLine = block
            .split('\n')
            .find((l) => l.startsWith('data: '));
          if (!dataLine) continue;

          const payload = JSON.parse(dataLine.slice(6));

          if (payload.type === 'stage_start') {
            updateStage(payload.stage, {
              state: 'running',
              label: payload.label,
              detail: payload.detail,
            });
          } else if (payload.type === 'stage_complete') {
            updateStage(payload.stage, {
              state: 'complete',
              durationMs: payload.durationMs,
              detail: payload.summary,
            });
          } else if (payload.type === 'review_complete') {
            setCurrentReport(payload.result);
            setHistory((prev) => [payload.result, ...prev].slice(0, 20));
            setTimeout(() => {
              reportAnchorRef.current?.scrollIntoView({
                behavior: 'smooth',
                block: 'start',
              });
            }, 120);
          } else if (payload.type === 'error') {
            throw new Error(payload.message);
          }
        }
      }
    } catch (err) {
      if (err && err.name === 'AbortError') return;
      const msg =
        err instanceof Error ? err.message : 'Unexpected review error.';
      setErrorMsg(msg);
      setStages((prev) =>
        prev.map((s) =>
          s.state === 'running' ? { ...s, state: 'error', detail: msg } : s
        )
      );
    } finally {
      setIsRunning(false);
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#F6F8FB] text-slate-900">
      {/* Top Bar: 3-zone contract */}
      <header className="sticky top-0 z-30 bg-white/95 backdrop-blur border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-6 h-16 flex items-center justify-between gap-8">
          {/* Zone 1: Brand wordmark */}
          <button
            type="button"
            onClick={() => setView('workbench')}
            className="text-lg font-display font-bold tracking-tight text-slate-900 whitespace-nowrap shrink-0 hover:text-blue-600 transition-colors"
          >
            SquadReview
          </button>

          {/* Zone 2: Navigation links */}
          <nav
            aria-label="Primary navigation"
            className="flex items-center gap-6 text-sm font-medium"
          >
            {[
              ['workbench', 'Workbench'],
              ['history', 'History'],
            ].map(([id, label]) => {
              const active = view === id;
              return (
                <button
                  key={id}
                  type="button"
                  onClick={() => setView(id)}
                  className={`py-1 border-b-2 transition-colors whitespace-nowrap shrink-0 ${
                    active
                      ? 'border-blue-600 text-slate-900'
                      : 'border-transparent text-slate-600 hover:text-slate-900 hover:border-slate-300'
                  }`}
                >
                  {label}
                </button>
              );
            })}
          </nav>

          {/* Zone 3: Single primary action */}
          <div className="flex items-center shrink-0">
            <button
              type="button"
              onClick={handleNewReview}
              className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-medium text-white bg-slate-900 rounded-md hover:bg-slate-800 transition-colors whitespace-nowrap shrink-0"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>New Review</span>
            </button>
          </div>
        </div>
      </header>

      <main className="flex-1 max-w-7xl w-full mx-auto px-6 py-7">
        {view === 'workbench' && (
          <div className="space-y-6">
            {/* Editorial Workbench Header */}
            <div className="flex flex-wrap items-end justify-between gap-4">
              <div>
                <h1 className="text-2xl sm:text-3xl font-semibold tracking-tight text-slate-900">
                  Multi-Agent Code Review & Debug Workbench
                </h1>
                <p className="mt-1.5 text-sm text-slate-600 max-w-2xl leading-relaxed">
                  Submit a Python or JavaScript snippet for collaborative bug
                  detection, style linting, automated fixes, and isolated
                  sandbox test verification.
                </p>
              </div>
              <div className="text-xs text-slate-500 whitespace-nowrap">
                Agentic RAG · Unified Diff · Isolated Sandbox
              </div>
            </div>

            {/* Code Input & Crew Scope Split */}
            <form
              onSubmit={handleRunReview}
              className="grid grid-cols-1 lg:grid-cols-12 gap-5 items-stretch"
            >
              {/* Synchronized Line-Numbered Code Editor (8 cols) */}
              <div className="lg:col-span-8 flex flex-col">
                <CodeEditor
                  code={code}
                  language={language}
                  onChangeCode={setCode}
                  onChangeLanguage={setLanguage}
                />
              </div>

              {/* Review Focus & Engineering Crew Panel (4 cols) */}
              <div className="lg:col-span-4 border border-slate-200 rounded-xl bg-white p-5 shadow-xs flex flex-col justify-between gap-5">
                <div className="space-y-5">
                  <div>
                    <label
                      htmlFor="student-goal"
                      className="block text-xs font-semibold text-slate-900 mb-1.5"
                    >
                      Review Focus or Question (Optional)
                    </label>
                    <textarea
                      id="student-goal"
                      rows={3}
                      value={studentGoal}
                      onChange={(e) => setStudentGoal(e.target.value)}
                      placeholder="e.g. Why does this fail on empty inputs, or check style and generate edge-case tests."
                      className="w-full px-3 py-2 text-sm text-slate-800 border border-slate-200 rounded-lg bg-slate-50/50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-500/25 focus:border-blue-600 resize-none transition-colors"
                    />
                  </div>

                  <div>
                    <div className="text-xs font-semibold text-slate-900 mb-2">
                      Assigned Engineering Crew
                    </div>
                    <div className="divide-y divide-slate-100 border border-slate-200 rounded-lg bg-slate-50/40">
                      {CREW_ROSTER.map((member) => {
                        const Icon = member.icon;
                        return (
                          <div
                            key={member.role}
                            className="px-3.5 py-2.5 flex items-start gap-2.5"
                          >
                            <Icon className="w-4 h-4 text-blue-600 shrink-0 mt-0.5" />
                            <div className="min-w-0">
                              <div className="text-xs font-semibold text-slate-900">
                                {member.role}
                              </div>
                              <div className="text-xs text-slate-600 leading-snug">
                                {member.scope}
                              </div>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                </div>

                <button
                  type="submit"
                  disabled={isRunning || !code.trim()}
                  className="w-full inline-flex items-center justify-center gap-2 px-4 py-2.5 text-sm font-medium text-white bg-blue-600 rounded-lg hover:bg-blue-700 disabled:opacity-45 disabled:cursor-not-allowed transition-colors whitespace-nowrap shadow-xs"
                >
                  <Play className="w-4 h-4" />
                  <span>
                    {isRunning ? 'Squad Reviewing...' : 'Run Squad Review'}
                  </span>
                </button>
              </div>
            </form>

            {/* Live Crew Pipeline Bar */}
            <AgentPipelineBar stages={stages} isRunning={isRunning} />

            {/* Error Banner */}
            {errorMsg && (
              <div className="border border-rose-200 bg-rose-50 rounded-xl px-4 py-3.5 flex items-start gap-2.5 text-sm text-rose-800">
                <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
                <div>
                  <span className="font-semibold">Review failed:</span>{' '}
                  {errorMsg}
                </div>
              </div>
            )}

            {/* Consolidated Report */}
            {currentReport && (
              <div ref={reportAnchorRef}>
                <ReviewReport
                  result={currentReport}
                  onApplyFix={handleApplyFixToEditor}
                />
              </div>
            )}
          </div>
        )}

        {view === 'history' && (
          <HistoryView
            history={history}
            onSelectReview={(review) => {
              setLanguage(review.language);
              setCode(review.originalCode);
              setStudentGoal(review.studentGoal);
              setCurrentReport(review);
              setStages(
                INITIAL_STAGES.map((s) => ({
                  ...s,
                  state: 'complete',
                  detail: 'Completed in saved session.',
                }))
              );
              setView('workbench');
            }}
            onClearHistory={() => setHistory([])}
          />
        )}
      </main>
    </div>
  );
}
