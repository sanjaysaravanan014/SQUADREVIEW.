import { EMBEDDING_MODEL, getGeminiClient } from './gemini.js';

const INITIAL_DOCS = [
  {
    id: 'py-mutable-defaults',
    title: 'Avoid Mutable Default Arguments in Python',
    category: 'bug_pattern',
    language: 'python',
    summary:
      'Default function arguments are evaluated once at function definition time, not on every call.',
    content:
      'Never use mutable objects like [] or {} as default parameter values in Python (e.g., def add_item(x, items=[])). Mutations persist across subsequent calls. Instead, default to None and initialize inside the function body: if items is None: items = [].',
    tags: ['python', 'default-arguments', 'list', 'dict', 'state-leak'],
  },
  {
    id: 'py-pep8-naming',
    title: 'PEP 8 Naming, Typing & Docstring Conventions',
    category: 'guideline',
    language: 'python',
    summary:
      'Use snake_case for functions and variables, PascalCase for classes, and explicit type hints.',
    content:
      'Follow PEP 8: functions and variables use snake_case; constants use UPPER_SNAKE_CASE; classes use CapWords. Add type annotations for parameters and return values, keep line length under 88-99 chars, avoid bare except clauses, and include concise docstrings on public functions.',
    tags: ['pep8', 'naming', 'type-hints', 'docstrings', 'readability'],
  },
  {
    id: 'algo-binary-search-bounds',
    title: 'Off-by-One & Infinite Loop Prevention in Binary Search',
    category: 'bug_pattern',
    language: 'general',
    summary:
      'Ensure loop invariants and pointer updates strictly shrink the search space on every iteration.',
    content:
      'When using inclusive bounds [left, right] with while left <= right, update left = mid + 1 and right = mid - 1. Setting left = mid or right = mid causes infinite loops on 2-element ranges. Always guard empty inputs (len == 0) before indexing.',
    tags: ['binary-search', 'off-by-one', 'infinite-loop', 'bounds', 'edge-case'],
  },
  {
    id: 'py-float-precision',
    title: 'Floating-Point Comparison & Division Guards',
    category: 'bug_pattern',
    language: 'python',
    summary:
      'Avoid exact equality (==) on floats and guard against ZeroDivisionError on empty aggregates.',
    content:
      'IEEE 754 binary floating-point arithmetic introduces rounding error (e.g., 0.1 + 0.2 != 0.3). Use math.isclose(a, b, rel_tol=1e-9) or Decimal for financial values. Always check divisor != 0 or empty sequences before computing averages or ratios.',
    tags: ['float', 'precision', 'zero-division', 'math', 'average'],
  },
  {
    id: 'py-exception-handling',
    title: 'Specific Exception Handling & Resource Management',
    category: 'guideline',
    language: 'python',
    summary:
      'Never swallow exceptions with bare except: pass; use context managers (with) for I/O.',
    content:
      'Bare except clauses catch KeyboardInterrupt and SystemExit, hiding real bugs. Catch specific exceptions (ValueError, KeyError, TypeError) and surface meaningful error messages. Use `with open(...)` so file descriptors close even when exceptions occur.',
    tags: ['exceptions', 'error-handling', 'context-manager', 'pep8'],
  },
  {
    id: 'py-recursion-memo',
    title: 'Recursion Base Cases & Memoization',
    category: 'bug_pattern',
    language: 'python',
    summary:
      'Validate negative/invalid inputs before recursing and memoize overlapping subproblems.',
    content:
      'Recursive functions without guarded lower bounds (e.g., n < 0 in factorial or fibonacci) cause RecursionError. Validate input domains early with ValueError and use @functools.lru_cache or iterative dynamic programming to avoid exponential O(2^n) blowup.',
    tags: ['recursion', 'base-case', 'memoization', 'complexity', 'fibonacci'],
  },
  {
    id: 'js-strict-equality',
    title: 'Strict Equality, NaN & Nullish Guarding in JavaScript',
    category: 'guideline',
    language: 'javascript',
    summary:
      'Always use === and !==, Number.isNaN(), and explicit null/undefined checks instead of truthy coercion.',
    content:
      'Loose equality (==) performs implicit type coercion (0 == "" is true, null == undefined is true). Always use === and !==. Note that !value treats 0, "", and false as missing; use value === null || value === undefined (or ??) when 0 or empty string are valid inputs.',
    tags: ['javascript', 'equality', 'coercion', 'nullish', 'falsy'],
  },
  {
    id: 'js-array-mutation',
    title: 'Avoiding Unintended Array & Object Mutation in JS',
    category: 'bug_pattern',
    language: 'javascript',
    summary:
      'Array.prototype.sort() and reverse() mutate arrays in place and sort numbers lexicographically by default.',
    content:
      'Calling arr.sort() without a comparator sorts numbers as strings ([10, 2] stays [10, 2]). Furthermore, sort() and splice() mutate the caller array. Copy first with [...arr].sort((a, b) => a - b) or use toSorted() when preserving immutability.',
    tags: ['javascript', 'sort', 'mutation', 'immutability', 'comparator'],
  },
  {
    id: 'js-async-errors',
    title: 'Async/Await Error Handling & Promise Pitfalls',
    category: 'bug_pattern',
    language: 'javascript',
    summary:
      'Await promises inside try/catch blocks and avoid Array.forEach with async callbacks.',
    content:
      'Array.prototype.forEach does not await async callbacks, leading to race conditions and unhandled rejections. Use for...of loops for sequential async work or Promise.all / Promise.allSettled for parallel work, wrapped in try/catch.',
    tags: ['javascript', 'async', 'await', 'promises', 'forEach'],
  },
  {
    id: 'sec-unsafe-eval-injection',
    title: 'Prevent Code Execution & Injection Vulnerabilities',
    category: 'security',
    language: 'general',
    summary:
      'Never pass untrusted input to eval(), exec(), Function(), or interpolated SQL/shell strings.',
    content:
      'Using eval(), exec(), or new Function() on user input enables arbitrary code execution. Use ast.literal_eval or JSON.parse for structured data, and parameterized queries or safe dispatch tables instead of dynamic evaluation.',
    tags: ['security', 'eval', 'injection', 'sanitize', 'owasp'],
  },
  {
    id: 'test-boundary-equivalence',
    title: 'Boundary Value Analysis & Edge-Case Test Design',
    category: 'testing',
    language: 'general',
    summary:
      'Test empty inputs, single-element inputs, duplicates, negative values, and invalid types.',
    content:
      'Effective unit test suites cover: (1) normal representative cases, (2) boundary inputs (empty array/string, 0, 1, min/max), (3) duplicate or already-sorted data, and (4) invalid input error paths (assertRaises / assert.throws). Keep each test deterministic and independent.',
    tags: ['testing', 'unit-test', 'edge-cases', 'boundary', 'unittest'],
  },
  {
    id: 'test-python-unittest',
    title: 'Python unittest Structure & Assertions Guide',
    category: 'testing',
    language: 'python',
    summary:
      'Use unittest.TestCase subclasses with descriptive test_ methods and assertRaises for error paths.',
    content:
      'Import the target module cleanly, inherit from unittest.TestCase, and use specific assertions (assertEqual, assertAlmostEqual, assertRaises, assertTrue) rather than plain assert statements so failure diagnostics show expected vs actual values.',
    tags: ['python', 'unittest', 'assertions', 'test-suite'],
  },
  {
    id: 'test-js-node-test',
    title: 'Node.js Built-in Test Runner (node:test & node:assert/strict)',
    category: 'testing',
    language: 'javascript',
    summary:
      'Write clean, dependency-free JavaScript tests using node:test and node:assert/strict.',
    content:
      'Use `import test from "node:test"; import assert from "node:assert/strict";` to write isolated unit tests. Prefer `assert.deepEqual` for arrays/objects, `assert.equal` for primitives, and `assert.throws` for expected exceptions.',
    tags: ['javascript', 'node:test', 'assert', 'unit-test'],
  },
  {
    id: 'js-clean-style',
    title: 'Modern JavaScript Naming, Const-First & Early Returns',
    category: 'guideline',
    language: 'javascript',
    summary:
      'Prefer const over let, avoid var, use camelCase identifiers, and flatten nested conditionals.',
    content:
      'Avoid var (function-scoped hoisting bugs). Default to const and use let only when reassigned. Use guard clauses with early returns to reduce nesting depth, and add JSDoc comments for non-trivial public functions.',
    tags: ['javascript', 'const', 'camelCase', 'early-return', 'readability'],
  },
];

const knowledgeStore = [...INITIAL_DOCS];
const embeddingCache = new Map();

function docToText(doc) {
  return `${doc.title}\nCategory: ${doc.category} (${doc.language})\nTags: ${doc.tags.join(', ')}\n${doc.summary}\n${doc.content}`;
}

function tokenize(text) {
  return text
    .toLowerCase()
    .replace(/[^a-z0-9_]+/g, ' ')
    .split(/\s+/)
    .filter((t) => t.length > 1);
}

function lexicalScore(query, doc) {
  const qTokens = tokenize(query);
  if (qTokens.length === 0) return 0;
  const docTokens = new Set(tokenize(docToText(doc)));
  const titleTokens = new Set(tokenize(doc.title + ' ' + doc.tags.join(' ')));
  let hits = 0;
  for (const tok of qTokens) {
    if (titleTokens.has(tok)) {
      hits += 1.5;
    } else if (docTokens.has(tok)) {
      hits += 1.0;
    }
  }
  return Math.min(1, hits / Math.max(3, qTokens.length * 1.1));
}

function cosineSimilarity(a, b) {
  if (a.length === 0 || a.length !== b.length) return 0;
  let dot = 0;
  let magA = 0;
  let magB = 0;
  for (let i = 0; i < a.length; i++) {
    dot += a[i] * b[i];
    magA += a[i] * a[i];
    magB += b[i] * b[i];
  }
  const denom = Math.sqrt(magA) * Math.sqrt(magB);
  return denom === 0 ? 0 : dot / denom;
}

async function embedSingleText(text) {
  let timer;
  try {
    const ai = getGeminiClient();
    const res = await Promise.race([
      ai.models.embedContent({
        model: EMBEDDING_MODEL,
        contents: text,
      }),
      new Promise((_, reject) => {
        timer = setTimeout(() => reject(new Error('Embed timeout')), 3500);
      }),
    ]);
    const vals = res.embeddings?.[0]?.values;
    return vals && vals.length > 0 ? vals : null;
  } catch {
    return null;
  } finally {
    clearTimeout(timer);
  }
}

async function ensureDocEmbeddings(docs) {
  const missing = docs.filter((d) => !embeddingCache.has(d.id));
  if (missing.length === 0) return true;
  let timer;
  try {
    const results = await Promise.race([
      Promise.all(
        missing.map(async (doc) => ({
          id: doc.id,
          vec: await embedSingleText(docToText(doc)),
        }))
      ),
      new Promise((resolve) => {
        timer = setTimeout(() => resolve([]), 4500);
      }),
    ]);
    let anyLoaded = false;
    for (const item of results) {
      if (item.vec) {
        embeddingCache.set(item.id, item.vec);
        anyLoaded = true;
      }
    }
    return anyLoaded || embeddingCache.size > 0;
  } catch {
    return embeddingCache.size > 0;
  } finally {
    clearTimeout(timer);
  }
}

export async function searchKnowledgeBase(queries, language, topK = 4) {
  const combinedQuery = queries.filter(Boolean).join(' | ').trim();
  const candidates = knowledgeStore.filter(
    (d) => !language || d.language === language || d.language === 'general'
  );

  if (!combinedQuery) {
    return candidates.slice(0, topK).map((doc) => ({
      ...doc,
      score: 0.75,
      matchedBy: 'lexical',
    }));
  }

  const [embeddingsReady, queryVector] = await Promise.all([
    ensureDocEmbeddings(candidates),
    embedSingleText(combinedQuery),
  ]);

  const scored = candidates.map((doc) => {
    const lex = Math.max(
      ...queries.map((q) => lexicalScore(q, doc)),
      lexicalScore(combinedQuery, doc)
    );
    const docVec = embeddingsReady ? embeddingCache.get(doc.id) : undefined;
    if (queryVector && docVec) {
      const vecScore = Math.max(0, cosineSimilarity(queryVector, docVec));
      const langBonus = language && doc.language === language ? 0.05 : 0;
      const hybridScore = Math.min(0.99, vecScore * 0.75 + lex * 0.25 + langBonus);
      return {
        ...doc,
        score: Number(hybridScore.toFixed(3)),
        matchedBy: lex > 0.15 ? 'hybrid' : 'vector',
      };
    }
    const langBonus = language && doc.language === language ? 0.08 : 0;
    return {
      ...doc,
      score: Number(Math.min(0.99, lex + langBonus).toFixed(3)),
      matchedBy: 'lexical',
    };
  });

  return scored.sort((a, b) => b.score - a.score).slice(0, topK);
}
