import { GoogleGenAI } from '@google/genai';

export const PRIMARY_MODEL = 'gemini-4-hydrogen';
export const FALLBACK_MODEL = 'gemini-3.1-flash-lite';
export const EMBEDDING_MODEL = 'gemini-embedding-2';

let cachedClient = null;
const dailyQuotaBlockedUntil = new Map();

export class GeminiConfigurationError extends Error {
  constructor(message) {
    super(message);
    this.name = 'GeminiConfigurationError';
  }
}

export function getGeminiClient() {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey || apiKey === 'MY_GEMINI_API_KEY') {
    throw new GeminiConfigurationError(
      'GEMINI_API_KEY is not configured. Add a valid key in Settings > Secrets.'
    );
  }
  if (!cachedClient) {
    cachedClient = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });
  }
  return cachedClient;
}

function isDailyQuotaExhausted(msg) {
  return (
    msg.includes('PerDay') ||
    msg.includes('FreeTier') ||
    msg.includes('free_tier') ||
    msg.includes('GenerateRequestsPerDay')
  );
}

function isTransientError(msg) {
  return (
    msg.includes('503') ||
    msg.includes('UNAVAILABLE') ||
    msg.includes('500') ||
    msg.includes('INTERNAL') ||
    msg.includes('timed out') ||
    (msg.includes('429') && !isDailyQuotaExhausted(msg))
  );
}

function callWithTimeout(promise, timeoutMs) {
  let timer;
  return Promise.race([
    promise,
    new Promise((_, reject) => {
      timer = setTimeout(
        () => reject(new Error(`Gemini request timed out after ${timeoutMs}ms`)),
        timeoutMs
      );
    }),
  ]).finally(() => clearTimeout(timer));
}

export async function generateStructuredJSON(options) {
  const ai = getGeminiClient();
  const baseOrder = options.preferFastModel
    ? [FALLBACK_MODEL, PRIMARY_MODEL]
    : [PRIMARY_MODEL, FALLBACK_MODEL];

  const now = Date.now();
  const availableOrder = baseOrder.filter(
    (m) => (dailyQuotaBlockedUntil.get(m) ?? 0) <= now
  );
  const modelOrder = availableOrder.length > 0 ? availableOrder : baseOrder;

  const timeoutMs = options.timeoutMs ?? 18000;
  const maxAttempts = options.maxAttemptsPerModel ?? 3;
  let lastError;

  for (const model of modelOrder) {
    for (let attempt = 1; attempt <= maxAttempts; attempt++) {
      try {
        const config = {
          systemInstruction: options.systemInstruction,
          responseMimeType: 'application/json',
          responseSchema: options.responseSchema,
        };

        if (model === PRIMARY_MODEL && options.thinkingLevel) {
          config.thinkingConfig = { thinkingLevel: options.thinkingLevel };
        }

        const response = await callWithTimeout(
          ai.models.generateContent({
            model,
            contents: options.contents,
            config,
          }),
          timeoutMs
        );

        const rawText = (response.text ?? '').trim();
        if (!rawText) {
          throw new Error(`Model ${model} returned empty output.`);
        }
        const parsed = JSON.parse(rawText);
        return { data: parsed, modelUsed: model };
      } catch (err) {
        lastError = err;
        const msg = err instanceof Error ? err.message : String(err);

        if (isDailyQuotaExhausted(msg)) {
          dailyQuotaBlockedUntil.set(model, Date.now() + 10 * 60 * 1000);
          break;
        }

        if (msg.includes('429')) {
          break;
        }

        if (isTransientError(msg) && attempt < maxAttempts) {
          await new Promise((resolve) => setTimeout(resolve, 900 * attempt));
          continue;
        }

        break;
      }
    }
  }

  throw lastError ?? new Error('All Gemini models failed to respond.');
}

export function formatGeminiError(err) {
  const raw = err instanceof Error ? err.message : String(err);
  if (err instanceof GeminiConfigurationError) {
    return { status: 400, message: raw, code: 'API_KEY_MISSING' };
  }
  if (raw.includes('PERMISSION_DENIED') || raw.includes('403')) {
    return {
      status: 403,
      message:
        'Gemini API permission denied. Please verify your API key in Settings > Secrets.',
      code: 'PERMISSION_DENIED',
    };
  }
  if (raw.includes('API_KEY_INVALID') || raw.includes('API key not valid')) {
    return {
      status: 400,
      message:
        'Gemini API key is invalid. Please update GEMINI_API_KEY in Settings > Secrets.',
      code: 'API_KEY_INVALID',
    };
  }
  if (raw.includes('RESOURCE_EXHAUSTED') || raw.includes('429')) {
    return {
      status: 429,
      message:
        'Free-tier daily quota reached for this API key. Selecting a billing-enabled API key in Settings > Secrets increases your quota.',
      code: 'RESOURCE_EXHAUSTED',
    };
  }
  if (raw.includes('503') || raw.includes('UNAVAILABLE') || raw.includes('timed out')) {
    return {
      status: 503,
      message:
        'Gemini model is temporarily experiencing high demand (and free-tier primary quota is exhausted). Please retry shortly or select a billing-enabled key in Settings > Secrets.',
      code: 'MODEL_UNAVAILABLE',
    };
  }
  return {
    status: 500,
    message: raw || 'Unexpected error communicating with Gemini API.',
    code: 'GEMINI_ERROR',
  };
}
