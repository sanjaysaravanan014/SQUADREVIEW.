import { ThinkingLevel, Type } from '@google/genai';
import { generateStructuredJSON } from './gemini.js';
import { searchKnowledgeBase } from './rag.js';
import { checkSyntaxInSandbox, runTestsInSandbox } from './sandbox.js';

function addLineNumbers(code) {
  return code
    .split('\n')
    .map((line, i) => `${String(i + 1).padStart(3, ' ')} | ${line}`)
    .join('\n');
}

function formatDocsForPrompt(docs) {
  if (docs.length === 0) return 'No external guidelines retrieved.';
  return docs
    .map(
      (d, i) =>
        `[Doc ${i + 1}: ${d.title} | category=${d.category} | score=${d.score}]\n${d.content}`
    )
    .join('\n\n');
}

function stripCodeFences(code) {
  const trimmed = code.trim();
  const fenceMatch = trimmed.match(/^```[a-zA-Z]*\n([\s\S]*?)\n```$/);
  return fenceMatch ? fenceMatch[1].trim() : trimmed;
}

function inferLocalIntent(code, language, studentGoal) {
  const text = `${studentGoal} ${code}`.toLowerCase();
  let primary = 'full_audit';
  if (/\b(bug|fix|error|crash|hang|fail|wrong|infinite|loop|why)\b/.test(text)) {
    primary = 'debugging';
  } else if (/\b(style|lint|pep8|pep 8|clean|naming|readable)\b/.test(text)) {
    primary = 'style_review';
  } else if (/\b(explain|how does|walkthrough|understand)\b/.test(text)) {
    primary = 'code_explanation';
  } else if (/\b(test|unittest|assert|coverage|edge case)\b/.test(text)) {
    primary = 'testing';
  }

  const queries = [
    `${language} ${primary.replace('_', ' ')} ${studentGoal}`.trim(),
    `${language} ${code.slice(0, 160).replace(/\s+/g, ' ')}`,
    `${language} unit testing edge cases`,
  ];

  return {
    primary,
    confidence: 0.86,
    rationale: `Routed to ${primary.replace('_', ' ')} workflow based on submission prompt and static code signals.`,
    retrievalQueries: queries,
    agentPlan: [
      'Detect logical errors, edge cases, and runtime risks',
      'Audit naming conventions and retrieved language guidelines',
      'Synthesize a clean rewrite preserving function signatures',
      'Generate and execute unit tests in the isolated sandbox',
    ],
  };
}

async function routeIntentAndRetrieve(code, language, studentGoal) {
  const localFallback = inferLocalIntent(code, language, studentGoal);
  let intent = localFallback;

  try {
    const { data } = await generateStructuredJSON({
      preferFastModel: true,
      timeoutMs: 6500,
      maxAttemptsPerModel: 1,
      systemInstruction:
        'You are the Intent Router & Agentic RAG Query Planner. Classify intent as one of: debugging, style_review, code_explanation, testing, or full_audit. Produce 2-3 targeted RAG search queries and a 4-step agentPlan.',
      contents: [
        `Language: ${language}`,
        `Student Goal: ${studentGoal || 'Full multi-agent code audit'}`,
        `Code:\n\`\`\`${language}\n${code.slice(0, 2000)}\n\`\`\``,
      ].join('\n\n'),
      thinkingLevel: ThinkingLevel.LOW,
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          primary: { type: Type.STRING },
          confidence: { type: Type.NUMBER },
          rationale: { type: Type.STRING },
          retrievalQueries: {
            type: Type.ARRAY,
            items: { type: Type.STRING },
          },
          agentPlan: {
            type: Type.ARRAY,
            items: { type: Type.STRING },
          },
        },
        required: [
          'primary',
          'confidence',
          'rationale',
          'retrievalQueries',
          'agentPlan',
        ],
      },
    });

    const validIntents = [
      'debugging',
      'style_review',
      'code_explanation',
      'testing',
      'full_audit',
    ];
    intent = {
      primary: validIntents.includes(data.primary)
        ? data.primary
        : localFallback.primary,
      confidence: Math.min(1, Math.max(0.1, Number(data.confidence) || 0.85)),
      rationale: data.rationale || localFallback.rationale,
      retrievalQueries:
        data.retrievalQueries?.length > 0
          ? data.retrievalQueries.slice(0, 3)
          : localFallback.retrievalQueries,
      agentPlan:
        data.agentPlan?.length > 0 ? data.agentPlan : localFallback.agentPlan,
    };
  } catch {
    intent = localFallback;
  }

  const retrievedDocs = await searchKnowledgeBase(
    intent.retrievalQueries,
    language,
    4
  );

  return { intent, retrievedDocs };
}

async function runCrewSynthesisPass(
  code,
  language,
  intent,
  studentGoal,
  syntaxOutput,
  docs
) {
  const harnessInstructions =
    language === 'python'
      ? `Write a Python unittest file saved as \`test_solution.py\` alongside \`solution.py\`.
Import using \`from solution import *\` (or explicit \`from solution import <names>\`).
Use \`unittest.TestCase\` with descriptive \`test_...\` methods and end with:
if __name__ == '__main__':
    unittest.main()`
      : `Write a JavaScript ESM test file using Node's built-in test runner saved as \`test_solution.mjs\` alongside \`solution.mjs\`.
Start with:
import test from 'node:test';
import assert from 'node:assert/strict';
import * as sol from './solution.mjs';
Call exported functions via \`sol.<name>(...)\`.`;

  const { data } = await generateStructuredJSON({
    preferFastModel: false,
    thinkingLevel: ThinkingLevel.MEDIUM,
    timeoutMs: 22000,
    maxAttemptsPerModel: 3,
    systemInstruction:
      'You are a coordinated 4-agent engineering review crew collaborating sequentially: (1) Bug-Finder Agent: find genuine logical errors, boundary/empty-input failures, off-by-one bugs, state mutations, and runtime risks with exact 1-based line numbers. (2) Style/Lint Agent: audit naming, type hints/docstrings/JSDoc, anti-patterns, and adherence to the retrieved RAG guidelines. (3) Fixer Agent: rewrite the code cleanly to resolve all bugs and style notes while strictly preserving original public function/class names and parameter compatibility, plus a clear educational explanation. (4) Test-Writer Agent: generate a deterministic unit test suite verifying normal, boundary, and bug-regression cases against the fixed code. Return pure source code in fixedCode and testCode with zero markdown fences.',
    contents: [
      `Language: ${language}`,
      `Routed Intent: ${intent.primary}`,
      `Student Goal: ${studentGoal || 'Comprehensive review, bug fix, style audit, and unit tests'}`,
      `Static Syntax Check: ${syntaxOutput.valid ? 'PASSED' : 'FAILED'}\n${syntaxOutput.output}`,
      `Retrieved Knowledge Base Guidelines:\n${formatDocsForPrompt(docs)}`,
      `Sandbox Test Harness Rules:\n${harnessInstructions}`,
      `Numbered Submitted Code:\n\`\`\`${language}\n${addLineNumbers(code)}\n\`\`\``,
    ].join('\n\n'),
    responseSchema: {
      type: Type.OBJECT,
      properties: {
        snippetTitle: { type: Type.STRING },
        bugs: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              line: { type: Type.INTEGER },
              title: { type: Type.STRING },
              severity: { type: Type.STRING },
              category: { type: Type.STRING },
              explanation: { type: Type.STRING },
              impact: { type: Type.STRING },
            },
            required: [
              'line',
              'title',
              'severity',
              'category',
              'explanation',
              'impact',
            ],
          },
        },
        styleIssues: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              line: { type: Type.INTEGER },
              rule: { type: Type.STRING },
              severity: { type: Type.STRING },
              message: { type: Type.STRING },
              suggestion: { type: Type.STRING },
              guidelineRef: { type: Type.STRING },
            },
            required: ['line', 'rule', 'severity', 'message', 'suggestion'],
          },
        },
        fixedCode: { type: Type.STRING },
        fixSummary: {
          type: Type.ARRAY,
          items: { type: Type.STRING },
        },
        explanation: { type: Type.STRING },
        testCode: { type: Type.STRING },
        testCasesSummary: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              name: { type: Type.STRING },
              purpose: { type: Type.STRING },
            },
            required: ['name', 'purpose'],
          },
        },
      },
      required: [
        'snippetTitle',
        'bugs',
        'styleIssues',
        'fixedCode',
        'fixSummary',
        'explanation',
        'testCode',
        'testCasesSummary',
      ],
    },
  });

  return {
    title: data.snippetTitle || 'Code Review Snippet',
    bugs: (data.bugs ?? []).map((b, i) => ({
      ...b,
      id: `bug-${i + 1}`,
      line: Math.max(1, Number(b.line) || 1),
    })),
    styleIssues: (data.styleIssues ?? []).map((s, i) => ({
      ...s,
      id: `style-${i + 1}`,
      line: Math.max(1, Number(s.line) || 1),
    })),
    fixedCode: stripCodeFences(data.fixedCode || code),
    fixSummary: data.fixSummary ?? [],
    explanation: data.explanation ?? '',
    testCode: stripCodeFences(data.testCode || ''),
    testCasesSummary: data.testCasesSummary ?? [],
  };
}

async function runReflectionRepair(fixedCode, testCode, language, sandboxOutput) {
  const { data } = await generateStructuredJSON({
    preferFastModel: false,
    thinkingLevel: ThinkingLevel.MEDIUM,
    timeoutMs: 18000,
    maxAttemptsPerModel: 2,
    systemInstruction:
      'You are in the Reflection & Self-Correction step. The sandbox executed testCode against fixedCode and failed. Diagnose whether the failure came from a remaining bug in fixedCode or an import/assertion mistake in testCode, and return repaired pure source code (no markdown fences) plus a 1-2 sentence reflectionNote.',
    contents: [
      `Language: ${language}`,
      `Current Fixed Code:\n\`\`\`${language}\n${fixedCode}\n\`\`\``,
      `Generated Test Suite:\n\`\`\`${language}\n${testCode}\n\`\`\``,
      `Sandbox Failure Output:\nSTDOUT:\n${sandboxOutput.stdout}\n\nSTDERR:\n${sandboxOutput.stderr}`,
    ].join('\n\n'),
    responseSchema: {
      type: Type.OBJECT,
      properties: {
        fixedCode: { type: Type.STRING },
        testCode: { type: Type.STRING },
        reflectionNote: { type: Type.STRING },
      },
      required: ['fixedCode', 'testCode', 'reflectionNote'],
    },
  });

  return {
    fixedCode: stripCodeFences(data.fixedCode || fixedCode),
    testCode: stripCodeFences(data.testCode || testCode),
    reflectionNote: data.reflectionNote,
  };
}

export async function runSquadReviewPipeline(params, emit) {
  const pipelineStart = Date.now();
  const { code, language, studentGoal } = params;

  const s1Start = Date.now();
  emit({
    type: 'stage_start',
    stage: 'intent_rag',
    label: 'Intent Router & Agentic RAG',
    detail:
      'Classifying request intent and querying coding guidelines via vector retrieval...',
  });

  const [{ intent, retrievedDocs }, syntaxCheckOriginal] = await Promise.all([
    routeIntentAndRetrieve(code, language, studentGoal),
    checkSyntaxInSandbox(code, language),
  ]);

  emit({
    type: 'stage_complete',
    stage: 'intent_rag',
    durationMs: Date.now() - s1Start,
    summary: `Intent: ${intent.primary.replace('_', ' ')} · Retrieved ${retrievedDocs.length} knowledge docs`,
    data: { intent, retrievedDocs },
  });

  const crewStart = Date.now();
  emit({
    type: 'stage_start',
    stage: 'bug_finder',
    label: 'Bug-Finder Agent',
    detail: 'Inspecting control flow, edge cases, bounds, and runtime safety...',
  });
  emit({
    type: 'stage_start',
    stage: 'style_lint',
    label: 'Style / Lint Agent',
    detail: 'Auditing naming conventions, readability, and retrieved guidelines...',
  });
  emit({
    type: 'stage_start',
    stage: 'fixer',
    label: 'Fixer Agent',
    detail: 'Preparing clean rewrite and educational explanation...',
  });

  const crew = await runCrewSynthesisPass(
    code,
    language,
    intent,
    studentGoal,
    syntaxCheckOriginal,
    retrievedDocs
  );

  const crewMs = Date.now() - crewStart;
  emit({
    type: 'stage_complete',
    stage: 'bug_finder',
    durationMs: crewMs,
    summary: `Found ${crew.bugs.length} bug${crew.bugs.length === 1 ? '' : 's'} / runtime risk${crew.bugs.length === 1 ? '' : 's'}`,
  });
  emit({
    type: 'stage_complete',
    stage: 'style_lint',
    durationMs: crewMs,
    summary: `Flagged ${crew.styleIssues.length} style & readability note${crew.styleIssues.length === 1 ? '' : 's'}`,
  });
  emit({
    type: 'stage_complete',
    stage: 'fixer',
    durationMs: crewMs,
    summary: `Generated clean rewrite with ${crew.fixSummary.length} targeted improvements`,
  });

  const s5Start = Date.now();
  emit({
    type: 'stage_start',
    stage: 'test_sandbox',
    label: 'Test-Writer & Sandbox',
    detail:
      'Executing generated unit tests on original vs. fixed code in isolated sandbox...',
  });

  let { fixedCode, testCode } = crew;

  let [sandboxOriginal, sandboxFixed] = await Promise.all([
    runTestsInSandbox(code, testCode, language),
    runTestsInSandbox(fixedCode, testCode, language),
  ]);

  emit({
    type: 'stage_complete',
    stage: 'test_sandbox',
    durationMs: Date.now() - s5Start,
    summary: sandboxFixed.passed
      ? `Verified ${sandboxFixed.testsRun || crew.testCasesSummary.length} tests passing on fixed code`
      : `Fixed code failed ${sandboxFixed.testsFailed} test(s) — triggering reflection`,
  });

  let reflectionApplied = false;
  let reflectionNote;

  if (!sandboxFixed.passed) {
    const s6Start = Date.now();
    emit({
      type: 'stage_start',
      stage: 'reflection',
      label: 'Agentic Reflection',
      detail: 'Analyzing sandbox failure trace and refining fix...',
    });

    try {
      const repaired = await runReflectionRepair(fixedCode, testCode, language, {
        stdout: sandboxFixed.stdout,
        stderr: sandboxFixed.stderr,
      });

      fixedCode = repaired.fixedCode;
      testCode = repaired.testCode;
      reflectionApplied = true;
      reflectionNote = repaired.reflectionNote;

      [sandboxOriginal, sandboxFixed] = await Promise.all([
        runTestsInSandbox(code, testCode, language),
        runTestsInSandbox(fixedCode, testCode, language),
      ]);

      emit({
        type: 'stage_complete',
        stage: 'reflection',
        durationMs: Date.now() - s6Start,
        summary: sandboxFixed.passed
          ? 'Reflection resolved failure — all sandbox tests now pass'
          : 'Reflection completed with diagnostic details',
      });
    } catch {
      emit({
        type: 'stage_complete',
        stage: 'reflection',
        durationMs: Date.now() - s6Start,
        summary: 'Reflection skipped due to model limits — inspect sandbox output',
      });
    }
  }

  const result = {
    id: `rev-${Date.now()}`,
    createdAt: new Date().toISOString(),
    title: crew.title,
    language,
    studentGoal: studentGoal.trim(),
    originalCode: code,
    intent,
    retrievedDocs,
    syntaxCheckOriginal,
    bugs: crew.bugs,
    styleIssues: crew.styleIssues,
    explanation: crew.explanation,
    fixedCode,
    fixSummary: crew.fixSummary,
    reflectionApplied,
    reflectionNote,
    testCode,
    testCasesSummary: crew.testCasesSummary,
    sandboxOriginal,
    sandboxFixed,
    totalDurationMs: Date.now() - pipelineStart,
  };

  emit({ type: 'review_complete', result });
  return result;
}
