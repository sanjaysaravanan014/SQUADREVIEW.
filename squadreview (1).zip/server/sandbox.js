import { spawn } from 'node:child_process';
import fs from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';

const EXECUTION_TIMEOUT_MS = 4000;
const MAX_OUTPUT_BYTES = 32 * 1024;

function runSubprocess(command, args, cwd, timeoutMs = EXECUTION_TIMEOUT_MS) {
  return new Promise((resolve) => {
    const start = Date.now();
    let stdout = '';
    let stderr = '';
    let timedOut = false;

    const child = spawn(command, args, {
      cwd,
      env: {
        PATH: process.env.PATH ?? '/usr/local/bin:/usr/bin:/bin',
        HOME: cwd,
        PYTHONDONTWRITEBYTECODE: '1',
        PYTHONIOENCODING: 'utf-8',
      },
      stdio: ['ignore', 'pipe', 'pipe'],
    });

    const timer = setTimeout(() => {
      timedOut = true;
      child.kill('SIGKILL');
    }, timeoutMs);

    child.stdout.on('data', (chunk) => {
      if (stdout.length < MAX_OUTPUT_BYTES) {
        stdout += chunk.toString('utf8').slice(0, MAX_OUTPUT_BYTES - stdout.length);
      }
    });

    child.stderr.on('data', (chunk) => {
      if (stderr.length < MAX_OUTPUT_BYTES) {
        stderr += chunk.toString('utf8').slice(0, MAX_OUTPUT_BYTES - stderr.length);
      }
    });

    child.on('error', (err) => {
      clearTimeout(timer);
      resolve({
        exitCode: 1,
        stdout,
        stderr: `${stderr}\n${err.message}`.trim(),
        durationMs: Date.now() - start,
        timedOut,
      });
    });

    child.on('close', (code) => {
      clearTimeout(timer);
      resolve({
        exitCode: code,
        stdout: stdout.trim(),
        stderr: stderr.trim(),
        durationMs: Date.now() - start,
        timedOut,
      });
    });
  });
}

function prepareJavaScriptModule(source) {
  if (/\bexport\s+(default|async|function|const|let|var|class|\{)/.test(source)) {
    return source;
  }

  const sanitized = source.replace(/module\.exports\s*=\s*[^;]+;?/g, '');
  const names = new Set();

  const fnMatches = sanitized.matchAll(/^(?:async\s+)?function\s+([A-Za-z_$][\w$]*)/gm);
  for (const m of fnMatches) names.add(m[1]);

  const classMatches = sanitized.matchAll(/^class\s+([A-Za-z_$][\w$]*)/gm);
  for (const m of classMatches) names.add(m[1]);

  const varMatches = sanitized.matchAll(/^(?:const|let|var)\s+([A-Za-z_$][\w$]*)\s*=/gm);
  for (const m of varMatches) names.add(m[1]);

  if (names.size === 0) {
    return sanitized;
  }

  const exportList = Array.from(names).join(', ');
  return `${sanitized}\n\nexport { ${exportList} };\n`;
}

function parsePythonTestCounts(stderr, stdout) {
  const combined = `${stdout}\n${stderr}`;
  const ranMatch = combined.match(/Ran\s+(\d+)\s+test/i);
  const testsRun = ranMatch ? Number(ranMatch[1]) : 0;

  let testsFailed = 0;
  const failMatch = combined.match(/failures=(\d+)/i);
  const errMatch = combined.match(/errors=(\d+)/i);
  if (failMatch) testsFailed += Number(failMatch[1]);
  if (errMatch) testsFailed += Number(errMatch[1]);

  if (testsFailed === 0 && /FAILED/i.test(combined)) {
    testsFailed = 1;
  }
  return { testsRun, testsFailed };
}

function parseNodeTestCounts(stdout, stderr) {
  const combined = `${stdout}\n${stderr}`;
  const testsMatch = combined.match(/tests\s+(\d+)/i);
  const failMatch = combined.match(/fail\s+(\d+)/i);
  const testsRun = testsMatch ? Number(testsMatch[1]) : 0;
  const testsFailed = failMatch ? Number(failMatch[1]) : 0;
  return { testsRun, testsFailed };
}

export async function checkSyntaxInSandbox(code, language) {
  const tmpDir = await fs.mkdtemp(path.join(os.tmpdir(), 'squadreview-syntax-'));
  try {
    if (language === 'python') {
      const filePath = path.join(tmpDir, 'solution.py');
      await fs.writeFile(filePath, code, 'utf8');
      const res = await runSubprocess('python3', ['-m', 'py_compile', filePath], tmpDir);
      return {
        valid: res.exitCode === 0,
        output: res.exitCode === 0 ? 'Python syntax check passed.' : res.stderr || res.stdout,
      };
    } else {
      const filePath = path.join(tmpDir, 'solution.mjs');
      await fs.writeFile(filePath, prepareJavaScriptModule(code), 'utf8');
      const res = await runSubprocess('node', ['--check', filePath], tmpDir);
      return {
        valid: res.exitCode === 0,
        output: res.exitCode === 0 ? 'JavaScript syntax check passed.' : res.stderr || res.stdout,
      };
    }
  } finally {
    await fs.rm(tmpDir, { recursive: true, force: true }).catch(() => {});
  }
}

export async function runTestsInSandbox(solutionCode, testCode, language) {
  const tmpDir = await fs.mkdtemp(path.join(os.tmpdir(), 'squadreview-exec-'));
  try {
    if (language === 'python') {
      const solPath = path.join(tmpDir, 'solution.py');
      const testPath = path.join(tmpDir, 'test_solution.py');

      await fs.writeFile(solPath, solutionCode, 'utf8');
      await fs.writeFile(testPath, testCode, 'utf8');

      const syntax = await runSubprocess('python3', ['-m', 'py_compile', solPath], tmpDir);
      if (syntax.exitCode !== 0) {
        return {
          passed: false,
          exitCode: syntax.exitCode,
          stdout: syntax.stdout,
          stderr: syntax.stderr || 'Syntax error in solution.py',
          durationMs: syntax.durationMs,
          testsRun: 0,
          testsFailed: 1,
          timedOut: false,
          syntaxValid: false,
        };
      }

      const res = await runSubprocess(
        'python3',
        ['-m', 'unittest', 'test_solution.py', '-v'],
        tmpDir
      );
      const { testsRun, testsFailed } = parsePythonTestCounts(res.stderr, res.stdout);
      return {
        passed: res.exitCode === 0 && !res.timedOut,
        exitCode: res.exitCode,
        stdout: res.stdout,
        stderr: res.timedOut
          ? `${res.stderr}\nExecution timed out after ${EXECUTION_TIMEOUT_MS}ms (possible infinite loop).`.trim()
          : res.stderr,
        durationMs: res.durationMs,
        testsRun,
        testsFailed: res.exitCode === 0 ? 0 : Math.max(1, testsFailed),
        timedOut: res.timedOut,
        syntaxValid: true,
      };
    } else {
      const solPath = path.join(tmpDir, 'solution.mjs');
      const testPath = path.join(tmpDir, 'test_solution.mjs');

      await fs.writeFile(solPath, prepareJavaScriptModule(solutionCode), 'utf8');
      await fs.writeFile(testPath, testCode, 'utf8');

      const syntax = await runSubprocess('node', ['--check', solPath], tmpDir);
      if (syntax.exitCode !== 0) {
        return {
          passed: false,
          exitCode: syntax.exitCode,
          stdout: syntax.stdout,
          stderr: syntax.stderr || 'Syntax error in solution.mjs',
          durationMs: syntax.durationMs,
          testsRun: 0,
          testsFailed: 1,
          timedOut: false,
          syntaxValid: false,
        };
      }

      const res = await runSubprocess('node', ['--test', testPath], tmpDir);
      const { testsRun, testsFailed } = parseNodeTestCounts(res.stdout, res.stderr);
      return {
        passed: res.exitCode === 0 && !res.timedOut,
        exitCode: res.exitCode,
        stdout: res.stdout,
        stderr: res.timedOut
          ? `${res.stderr}\nExecution timed out after ${EXECUTION_TIMEOUT_MS}ms (possible infinite loop).`.trim()
          : res.stderr,
        durationMs: res.durationMs,
        testsRun,
        testsFailed: res.exitCode === 0 ? 0 : Math.max(1, testsFailed),
        timedOut: res.timedOut,
        syntaxValid: true,
      };
    }
  } finally {
    await fs.rm(tmpDir, { recursive: true, force: true }).catch(() => {});
  }
}
