import 'dotenv/config';
import { runSquadReviewPipeline } from '../server/agents.js';

const SAMPLE_BUGGY_PYTHON = `def binary_search(arr, target):
    left = 0
    right = len(arr)

    while left <= right:
        mid = (left + right) // 2
        if arr[mid] == target:
            return mid
        elif arr[mid] < target:
            left = mid
        else:
            right = mid - 1
    return -1`;

async function main() {
  console.log('=== SquadReview CLI Quick Demo ===\n');
  console.log('Submitted Python Snippet:\n');
  console.log(SAMPLE_BUGGY_PYTHON);
  console.log('\nGoal: Find why binary_search hangs or crashes on empty lists.\n');

  const result = await runSquadReviewPipeline(
    {
      language: 'python',
      code: SAMPLE_BUGGY_PYTHON,
      studentGoal: 'Find why binary_search hangs or crashes on empty lists.',
    },
    (event) => {
      if (event.type === 'stage_start') {
        console.log(`-> [START] ${event.label}: ${event.detail}`);
      } else if (event.type === 'stage_complete') {
        console.log(
          `   [DONE]  ${event.stage} (${(event.durationMs / 1000).toFixed(2)}s): ${event.summary}`
        );
      } else if (event.type === 'error') {
        console.error(`   [ERROR] ${event.message}`);
      }
    }
  );

  console.log('\n=== Consolidated Review Summary ===');
  console.log(`Title:   ${result.title}`);
  console.log(
    `Intent:  ${result.intent.primary} (${Math.round(result.intent.confidence * 100)}% confidence)`
  );
  console.log(
    `RAG Docs (${result.retrievedDocs.length}): ${result.retrievedDocs
      .map((d) => `${d.title} [${Math.round(d.score * 100)}% ${d.matchedBy}]`)
      .join(' | ')}`
  );

  console.log(`\nBugs Found (${result.bugs.length}):`);
  for (const bug of result.bugs) {
    console.log(
      `  - [Line ${bug.line} | ${bug.severity.toUpperCase()}] ${bug.title}: ${bug.explanation}`
    );
  }

  console.log(`\nStyle Notes (${result.styleIssues.length}):`);
  for (const style of result.styleIssues) {
    console.log(`  - [Line ${style.line}] ${style.rule}: ${style.message}`);
  }

  console.log('\nFixed Code:\n');
  console.log(result.fixedCode);

  console.log('\nIsolated Sandbox Verification:');
  console.log(
    `  Original Code -> passed=${result.sandboxOriginal.passed} (${result.sandboxOriginal.durationMs}ms)`
  );
  console.log(
    `  Fixed Code    -> passed=${result.sandboxFixed.passed}, testsRun=${result.sandboxFixed.testsRun} (${result.sandboxFixed.durationMs}ms)`
  );
}

main()
  .then(() => process.exit(0))
  .catch((err) => {
    console.error('Demo failed:', err instanceof Error ? err.message : err);
    process.exit(1);
  });
